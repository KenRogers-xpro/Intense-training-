// let slideContainer = document.querySelector(".slider-container");

let slides = document.querySelector(".slider-container")
let slide = document.querySelectorAll(".slide")

let nextBtn = document.getElementById("next")
let prevBtn = document.getElementById("prev")


let counter = 0;

let slideCount = slide.length;


nextBtn.addEventListener ("click", function (){

    counter ++;

    if (counter >= slideCount) counter = 0;
    slides.style.transform = `translateX(-${counter * 100}%)`

})
prevBtn.onclick = function () {
    counter --;
    if (counter < 0) counter = slideCount - 1;
    slides.style.transform = `translateX(-${counter * 100}%)`

}










let header = document.getElementById("header");

// Wait for DOM ready in case script is moved or executed before load
document.addEventListener('DOMContentLoaded', () => {
    // The visual viewport emits the scroll event for the page — listen on window
    window.addEventListener('scroll', function () {
        if (window.scrollY > 930) {
            header.classList.add("header-scroll")
        } else {
            header.classList.remove("header-scroll")
        }
        // console.log('I have been scrolled', { scrollY: window.scrollY });
    }, { passive: true });
});